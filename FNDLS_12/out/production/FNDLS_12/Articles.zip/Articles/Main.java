package Articles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] text = scanner.nextLine().split(", ");
        String initialTitle = text[0];
        String initialContent = text[1];
        String initialAuthor = text[2];
        Article article = new Article(initialTitle, initialContent, initialAuthor);

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] tokens = scanner.nextLine().split(": ");
            String command = tokens[0];
            String data = tokens[1];

            if (command.equalsIgnoreCase("edit")) {
                article.edit(data);
            } else if (command.equalsIgnoreCase("ChangeAuthor")) {
                article.changeAuthor(data);
            } else if (command.equalsIgnoreCase("rename")) {
                article.rename(data);
            }
        }
        System.out.println(article);

    }
}
